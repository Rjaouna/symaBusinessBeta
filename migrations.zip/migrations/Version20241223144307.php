<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20241223144307 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE user CHANGE code_postal_id code_zone_id INT DEFAULT NULL');
        $this->addSql('ALTER TABLE user ADD CONSTRAINT FK_8D93D649A78B7B37 FOREIGN KEY (code_zone_id) REFERENCES zone (id)');
        $this->addSql('CREATE INDEX IDX_8D93D649A78B7B37 ON user (code_zone_id)');
        $this->addSql('ALTER TABLE zone ADD code_zone VARCHAR(20) NOT NULL, DROP code_postal');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_A0EBC0079600AAC6 ON zone (code_zone)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE user DROP FOREIGN KEY FK_8D93D649A78B7B37');
        $this->addSql('DROP INDEX IDX_8D93D649A78B7B37 ON user');
        $this->addSql('ALTER TABLE user CHANGE code_zone_id code_postal_id INT DEFAULT NULL');
        $this->addSql('DROP INDEX UNIQ_A0EBC0079600AAC6 ON zone');
        $this->addSql('ALTER TABLE zone ADD code_postal VARCHAR(10) NOT NULL, DROP code_zone');
    }
}
